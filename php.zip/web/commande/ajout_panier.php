<?php
require_once './web/session/session.php';

include('./verif_panier.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['pla_num'])) {
        array_push($_SESSION['panier']['produits'], $_POST['pla_num']);
    }

    header('Location: ../../index.php?page=plat.php');
    exit;
}

?>